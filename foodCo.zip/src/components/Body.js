import RestaurantCard from "./RestaurantCard";
import restaurantList from "../utils/mockData";
import { useState, useEffect } from "react";

// Whenever a state variable updates, React re-renders the ui
const Body = () => {
  const [resList, setResList] = useState(restaurantList);
  // cb of useEffect gets called after your component renders
  useEffect(() => {
    console.log("useEffect called...");
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
        const data = await fetch(
          "https://foodfire.onrender.com/api/restaurants?lat=12.991733&lng=77.713175&page_type=DESKTOP_WEB_LISTING"
        );
      const jsonValue = await data.json();
      console.log(jsonValue.data.cards);
      setResList(jsonValue.data.cards);
    } catch (error) {
      console.log("Failed calling API", error);
    }
  };

  function getResFilter() {
    setResList(
      resList.filter((item) => {
        return item.data.avgRating > 4;
      })
    );
  }

  return (
    <div className="body">
      <div className="filter">
        <button className="filter-btn" onClick={getResFilter}>
          Top Rated Restaurants
        </button>
      </div>
      <div className="res-container">
        {resList.map((resList) => (
          <RestaurantCard key={resList.id} resData={resList} />
        ))}
      </div>
    </div>
  );
};

export default Body;
