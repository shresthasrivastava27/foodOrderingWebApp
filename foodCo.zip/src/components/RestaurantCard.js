// import { CDN_URL } from "../utils/constants";
// import { listOfRestaurants } from "../utils/mockData";

// const RestaurantCard = (props) => {
//   const { resData } = props;

//   return (
//     <div className="res-container">
//       {listOfRestaurants?.map((restaurant, index) => {
//         const {
//           cloudinaryImageId,
//           name,
//           cuisines,
//           avgRating,
//           costForTwo,
//           deliveryTime,
//         } = restaurant.data;

//         return (
//           <div className="res-card" key={index}>
//             <img
//               className="res-logo"
//               alt="res-logo"
//               src={CDN_URL + cloudinaryImageId}
//             />
//             <h3>{name}</h3>
//             <h4>{cuisines.join(", ")}</h4>
//             <h4>{avgRating} stars</h4>
//             <h4>₹{costForTwo / 100} for two</h4>
//             <h4>{deliveryTime} minutes</h4>
//           </div>
//         );
//       })}
//     </div>
//   );
// };

// export default RestaurantCard;

// const RestaurantCard = ({resData}) => {
//   console.log(resData,"dataaa")
//   const {data:{name, cuisines, avgRating, costForTwo, cloudinaryImageId, deliveryTime }} = resData
//   return (
//       <>
//       <div className="card">
//           <img src={`${CDN_URL}${cloudinaryImageId}`} alt="food pic" height={"200px"} />
//           <h2>{name}</h2>
//           <h4>{cuisines.join(", ")}</h4>
//           <h5>Rating <span  className={avgRating >= 4 ? "rating-high" : "rating-low"}>{avgRating}</span></h5>
//           <h6>Cost For Two {costForTwo / 100}</h6>
//           <h6>Delivery Time {deliveryTime}</h6>
//       </div>
//       </>
//   )
// }

// export default RestaurantCard


import { CDN_URL } from "../utils/constants";

const RestaurantCard = ({ resData }) => {
  // Check if resData exists and has the expected structure
  if (!resData || !resData.data) {
    return <div>Loading restaurant data...</div>;
  }

  const {
    name,
    cuisines,
    avgRating,
    costForTwo,
    cloudinaryImageId,
    deliveryTime
  } = resData.data;

  return (
    <div className="card">
      <img 
        src={`${CDN_URL}${cloudinaryImageId}`} 
        alt="food pic" 
        height={"200px"} 
      />
      <h2>{name}</h2>
      <h4>{cuisines.join(", ")}</h4>
      <h5>
        Rating{" "}
        <span className={avgRating >= 4 ? "rating-high" : "rating-low"}>
          {avgRating}
        </span>
      </h5>
      <h6>Cost For Two {costForTwo / 100}</h6>
      <h6>Delivery Time {deliveryTime}</h6>
    </div>
  );
};

export default RestaurantCard;